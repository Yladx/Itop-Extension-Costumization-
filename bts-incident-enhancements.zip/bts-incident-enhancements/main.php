<?php

/**
 * Back-office CSS: show reopen_count / last_action_note only in view (and print) mode.
 */
class BTSIncidentEnhancementStyles implements iBackofficeLinkedStylesheetsExtension
{
	public function GetLinkedStylesheetsAbsUrls(): array
	{
		$sModuleFolder = basename(__DIR__);

		return array(
			utils::GetAbsoluteUrlModulesRoot().$sModuleFolder.'/css/incident-view-only-fields.css',
		);
	}
}
