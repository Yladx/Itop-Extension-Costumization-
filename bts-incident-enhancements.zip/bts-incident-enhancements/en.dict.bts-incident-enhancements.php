<?php
/**
 * Localized data
 *
 * @copyright   Copyright (C) 2013 XXXXX
 * @license     http://opensource.org/licenses/AGPL-3.0
 */

Dict::Add('EN US', 'English', 'English', array(

	// New Incident status value
	'Class:Incident/Attribute:status/Value:pending_provider' => 'Pending provider',

	// New stimulus
	'Class:Incident/Stimulus:ev_pending_provider' => 'Wait for Provider',

	// New Incident extra fields
	'Class:Incident/Attribute:incident_place_of_incident' => 'Place of Incident',
	'Class:Incident/Attribute:incident_size_impact' => 'Size of Impact',
	'Class:Incident/Attribute:incident_tools_methods' => 'Tools / Methods',
	'Class:Incident/Attribute:incident_vulnerabilities' => 'Vulnerabilities',
	'Class:Incident/Attribute:incident_others' => 'Others',

	'Class:Ticket/Attribute:priority_rank' => 'Priority rank',

));


?>
