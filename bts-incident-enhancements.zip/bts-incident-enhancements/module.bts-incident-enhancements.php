<?php
//
// iTop module definition file
//

SetupWebPage::AddModule(
	__FILE__,
	'bts-incident-enhancements/1.0.4', // 🔥 bump version
	array(
		// Identification
		'label' => 'bts-incident-enhancements',
		'category' => 'business',

		// Dependencies (keep compatible with your iTop version)
		'dependencies' => array(
			'itop-config-mgmt/3.0.0',
			'itop-tickets/3.0.0',
			'itop-incident-mgmt-itil/3.0.4'
		),

		'mandatory' => false,
		'visible' => true,

		// ✅ FIX: Use XML datamodel instead of PHP
		'datamodel' => array(
			'datamodel.bts-incident-enhancements.xml',
			'main.php',
		),

		'webservice' => array(),
		'data.struct' => array(),
		'data.sample' => array(),

		// Documentation
		'doc.manual_setup' => '',
		'doc.more_information' => '',

		// Settings
		'settings' => array(),
	)
);
?>