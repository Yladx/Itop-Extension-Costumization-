<?php
//
// iTop module definition file
//

SetupWebPage::AddModule(
	__FILE__,
	'bts-isms-dictionary/1.0.0',
	array(
		'label' => 'BTS ISMS Dictionary',
		'category' => 'business',
		'dependencies' => array(
			'itop-tickets/3.0.0',
			'itop-incident-mgmt-itil/3.0.0',
		),
		'mandatory' => false,
		'visible' => true,
		'datamodel' => array(
			'model.bts-isms-dictionary.php',
			'main.php',
		),
		'webservice' => array(),
		'data.struct' => array(),
		'data.sample' => array(),
		'doc.manual_setup' => '',
		'doc.more_information' => '',
		'settings' => array(),
	)
);

?>

