<?php
// PHP Data Model definition file for bts-isms-dictionary extension.

