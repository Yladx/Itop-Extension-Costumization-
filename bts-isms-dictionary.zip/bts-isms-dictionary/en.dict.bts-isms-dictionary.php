<?php
/**
 * BTS ISMS dictionary overrides (EN US)
 */

Dict::Add('EN US', 'English', 'English', array(
	// Fieldsets / sections
	'Ticket:baseinfo' => 'FIELD - General Information',
	'Ticket:Type' => 'Scope of Incident',
	'Ticket:moreinfo' => 'More Information',
	'Ticket:support' => 'Severity of incident',
	'Ticket:resolution' => 'Details of actions taken (in chronological order)',
	'Ticket:contact' => 'Contacts - NOT INCLUDED',
	'Ticket:date' => 'Dates',

	// General information labels
	'Class:Ticket/Attribute:org_id' => 'Department',
	'Class:Ticket/Attribute:caller_id' => 'Name of person Reporting',
	'Class:Incident/Attribute:origin' => 'Origin',
	'Class:Incident/Attribute:status' => 'Status',
	'Class:Ticket/Attribute:close_date' => 'Date and time close',
	'Class:Ticket/Attribute:end_date' => 'Actual date and time',
	'Class:Ticket/Attribute:description' => 'DESCRIPTION OF INCIDENT',

	// Scope of incident labels
	'Class:Ticket/Attribute:functionalcis_list' => 'Network/systems/applications affected',
	'Class:Incident/Attribute:origin+' => 'Origin or source of the incident',

	// More information labels
	'Class:Ticket/Attribute:finalclass' => 'Type of incident',
	'Class:Incident/Attribute:servicesubcategory_id' => 'Service subcategory',

	// Severity of incident labels
	'Class:Incident/Attribute:impact' => 'Impact',
	'Class:Incident/Attribute:urgency' => 'Urgency',
	'Class:Incident/Attribute:priority' => 'Priority',

	// Details of actions taken labels
	'Class:Incident/Attribute:public_log' => 'Containment',
	'Class:Incident/Attribute:pending_reason' => 'Mitigation',
	'Class:Incident/Attribute:solution' => 'Recovery',
	'Class:Ticket/Attribute:private_log' => 'Follow-up actions required',

	// Dates labels
	'Class:Ticket/Attribute:start_date' => 'Start date',
	'Class:Ticket/Attribute:last_update' => 'Last update',
	'Class:Incident/Attribute:tto_escalation_deadline' => 'TTO Deadline',

	// Optional custom attributes (will apply only if they exist in your datamodel)
	'Class:Incident/Attribute:place_of_incident' => 'PLACE OF INCIDENT',
	'Class:Incident/Attribute:size_impact_of_incident' => 'Size/impact of incident',
	'Class:Incident/Attribute:tools_or_attack_methods_used' => 'Tools or attack methods used',
	'Class:Incident/Attribute:vulnerabilities_exploited' => 'Vulnerabilities exploited',
	'Class:Incident/Attribute:others' => 'Others',
));

?>

