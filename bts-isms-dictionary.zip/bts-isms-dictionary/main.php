<?php
// main.php: optional runtime code for bts-isms-dictionary extension.

