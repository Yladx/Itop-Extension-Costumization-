<?php

// main.custom-login.php : the place to store php code
// don't forget to update the module.custom-login.php file
// to include this file !
//
// Trying to include the php code needed to customize the login screen.
// source : 
// https://www.itophub.io/wiki/page?id=2_7_0:customization:login_screen

class CustomCSSLoginExtension implements iLoginUIExtension
{
	public function ListSupportedLoginModes()
	{
		// as stated by Stephen
		// return null;
		return array('form');
	}

	public function GetTwigContext()
	{
		$oLoginContext = new LoginTwigContext();
		$sModuleFolder = basename(__DIR__);
		$oLoginContext->AddCSSFile(utils::GetAbsoluteUrlModulesRoot().$sModuleFolder.'/css/custom.css');
		return $oLoginContext;
	}
}
