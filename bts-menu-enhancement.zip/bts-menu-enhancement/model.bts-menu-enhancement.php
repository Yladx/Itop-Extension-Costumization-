<?php
// PHP Data Model definition file for bts-menu-enhancement extension.

