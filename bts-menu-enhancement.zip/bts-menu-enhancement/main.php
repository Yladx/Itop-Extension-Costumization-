<?php

/**
 * Inject custom stylesheet in backoffice pages.
 */
class BTSMenuEnhancementStyles implements iBackofficeLinkedStylesheetsExtension
{
	public function GetLinkedStylesheetsAbsUrls(): array
	{
		$sModuleFolder = basename(__DIR__);
		return array(
			utils::GetAbsoluteUrlModulesRoot().$sModuleFolder.'/css/menu-enhancement.css',
		);
	}
}

