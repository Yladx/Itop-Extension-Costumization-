<?php
//
// iTop module definition file
//

SetupWebPage::AddModule(
	__FILE__,
	'bts-menu-enhancement/1.0.0',
	array(
		'label' => 'BTS Menu Enhancement',
		'category' => 'business',
		'dependencies' => array(),
		'mandatory' => false,
		'visible' => true,
		'datamodel' => array(
			'model.bts-menu-enhancement.php',
			'main.php',
		),
		'webservice' => array(),
		'data.struct' => array(),
		'data.sample' => array(),
		'doc.manual_setup' => '',
		'doc.more_information' => '',
		'settings' => array(),
	)
);

?>

