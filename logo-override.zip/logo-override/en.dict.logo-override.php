<?php
/**
 * Localized data
 */
Dict::Add('EN US', 'English', 'English', array(
	// Dictionary entries go here
));
?>

