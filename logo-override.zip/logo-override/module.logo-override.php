<?php
//
// iTop module definition file
//

SetupWebPage::AddModule(
	__FILE__, // Path to the current file, all other file names are relative to the directory containing this file
	'logo-override/0.0.1',
	array(
		// Identification
		//
		'label' => 'BTS-LOGIN LOGO OVERRIDE',
		'category' => 'authentication',

		// Setup
		//
		'dependencies' => array(),
		'mandatory' => true,
		'visible' => true,

		// Components
		//
		'datamodel' => array(
			'model.logo-override.php',
			'main.php'
		),
		'webservice' => array(),
		'data.struct' => array(),
		'data.sample' => array(),

		// Documentation
		//
		'doc.manual_setup' => '',
		'doc.more_information' => '',

		// Default settings
		//
		'settings' => array(
			// Module specific settings go here, if any
		),
	)
);

?>

