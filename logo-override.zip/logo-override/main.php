<?php
use Combodo\iTop\Application\Branding;

/**
 * Ensure iTop branding logos are overridden for all logo types.
 *
 * iTop resolves branding images through `env-<env>/branding/logos.json`.
 * This extension copies custom logo SVGs into `env-<env>/branding/` and
 * updates `logos.json` so Branding::GetLogo* methods return them.
 */
class LogoBrandingOverride
{
	public static function Ensure()
	{
		static $bDone = false;
		if ($bDone)
		{
			return;
		}
		$bDone = true;

		try
		{
			$sEnv = utils::GetCurrentEnvironment();
			$sBrandingDir = APPROOT.'env-'.$sEnv.'/branding/';
			$sLogosJsonPath = $sBrandingDir.'logos.json';

			if (!is_dir($sBrandingDir))
			{
				@mkdir($sBrandingDir, 0775, true);
			}

			// Expected names inside this extension.
			// You can replace these files later without changing any code.
			$sExtImagesDir = __DIR__.'/images/logos/';
			$sIsmsPng = $sExtImagesDir.'ISMS.png';
			$aFallbackSources = array(
				Branding::ENUM_LOGO_TYPE_LOGIN_LOGO => APPROOT.'images/logos/logo-itop-simple-dark.svg',
				Branding::ENUM_LOGO_TYPE_MAIN_LOGO_FULL => APPROOT.'images/logos/logo-itop-baseline-dark.svg',
				Branding::ENUM_LOGO_TYPE_MAIN_LOGO_COMPACT => APPROOT.'images/logos/logo-itop-compact-dark.svg',
				Branding::ENUM_LOGO_TYPE_PORTAL_LOGO => APPROOT.'images/logos/logo-itop-baseline-light.svg',
			);

			// If ISMS.png is provided, use it for all logo types.
			// Otherwise, fall back to the SVGs (if you add them to this extension folder).
			$aExtSourceCandidates = array();
			$aLogoMap = array();
			if (file_exists($sIsmsPng))
			{
				$aExtSourceCandidates[Branding::ENUM_LOGO_TYPE_LOGIN_LOGO] = $sIsmsPng;
				$aExtSourceCandidates[Branding::ENUM_LOGO_TYPE_MAIN_LOGO_FULL] = $sIsmsPng;
				$aExtSourceCandidates[Branding::ENUM_LOGO_TYPE_MAIN_LOGO_COMPACT] = $sIsmsPng;
				$aExtSourceCandidates[Branding::ENUM_LOGO_TYPE_PORTAL_LOGO] = $sIsmsPng;

				$aLogoMap = array(
					Branding::ENUM_LOGO_TYPE_LOGIN_LOGO => '/branding/login-logo.png',
					Branding::ENUM_LOGO_TYPE_MAIN_LOGO_FULL => '/branding/main-logo-full.png',
					Branding::ENUM_LOGO_TYPE_MAIN_LOGO_COMPACT => '/branding/main-logo-compact.png',
					Branding::ENUM_LOGO_TYPE_PORTAL_LOGO => '/branding/portal-logo.png',
				);
			}
			else
			{
				$aExtSourceCandidates = array(
					Branding::ENUM_LOGO_TYPE_LOGIN_LOGO => $sExtImagesDir.'login-logo.svg',
					Branding::ENUM_LOGO_TYPE_MAIN_LOGO_FULL => $sExtImagesDir.'main-logo-full.svg',
					Branding::ENUM_LOGO_TYPE_MAIN_LOGO_COMPACT => $sExtImagesDir.'main-logo-compact.svg',
					Branding::ENUM_LOGO_TYPE_PORTAL_LOGO => $sExtImagesDir.'portal-logo.svg',
				);

				$aLogoMap = array(
					Branding::ENUM_LOGO_TYPE_LOGIN_LOGO => '/branding/login-logo.svg',
					Branding::ENUM_LOGO_TYPE_MAIN_LOGO_FULL => '/branding/main-logo-full.svg',
					Branding::ENUM_LOGO_TYPE_MAIN_LOGO_COMPACT => '/branding/main-logo-compact.svg',
					Branding::ENUM_LOGO_TYPE_PORTAL_LOGO => '/branding/portal-logo.svg',
				);
			}

			// Copy updated images if the source differs from what is already in env branding.
			$bAnyCopy = false;
			foreach ($aLogoMap as $sType => $sTargetRelPath)
			{
				$sSrc = $aExtSourceCandidates[$sType] ?? '';
				if (empty($sSrc) || !file_exists($sSrc))
				{
					$sSrc = $aFallbackSources[$sType] ?? '';
				}

				if (!file_exists($sSrc))
				{
					continue;
				}

				$sDestFileName = basename($sTargetRelPath);
				$sDestPath = $sBrandingDir.$sDestFileName;

				$iSrcHash = @md5_file($sSrc);
				$iDestHash = file_exists($sDestPath) ? @md5_file($sDestPath) : '';
				if (empty($iSrcHash) || empty($iDestHash) || ($iSrcHash !== $iDestHash))
				{
					@copy($sSrc, $sDestPath);
					$bAnyCopy = true;
				}
			}

			// Always ensure logos.json contains our expected map (even if files did not change).
			$sExpectedJson = json_encode($aLogoMap);
			$sCurrentJson = file_exists($sLogosJsonPath) ? @file_get_contents($sLogosJsonPath) : '';
			if ($bAnyCopy || ($sExpectedJson !== $sCurrentJson))
			{
				@file_put_contents($sLogosJsonPath, $sExpectedJson);
			}
		}
		catch (Exception $e)
		{
			// Avoid breaking page load if permissions/files are not writable.
		}
	}
}

// Apply branding override as soon as the module is loaded.
LogoBrandingOverride::Ensure();

/**
 * Login screen extension that allows replacing the login template.
 * The overridden template still uses `sDisplayIcon`, so the logo comes from Branding.
 */
class LoginLogoChangeExtension implements iLoginUIExtension
{
	public function ListSupportedLoginModes()
	{
		return array('form');
	}

	public function GetTwigContext()
	{
		$oLoginContext = new LoginTwigContext();

		// Let Twig resolve `base.html.twig` from this module instead of core.
		$oLoginContext->SetLoaderPath(__DIR__.'/templates/pages/login');

		return $oLoginContext;
	}
}

