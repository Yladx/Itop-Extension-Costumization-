<?php
//
// iTop module definition file
//

SetupWebPage::AddModule(
	__FILE__,
	'bts-menu-enhancement/1.0.2',
	array(
		'label' => 'BTS Menu Enhancement',
		'category' => 'business',
		'dependencies' => array(
			'itop-structure/3.0.0',
			'itop-incident-mgmt-itil/3.0.0',
			'itop-service-mgmt/3.0.0',
		),
		'mandatory' => false,
		'visible' => true,
		'datamodel' => array(
			'datamodel.bts-menu-enhancement.xml',
			'model.bts-menu-enhancement.php',
			'main.php',
		),
		'webservice' => array(),
		'data.struct' => array(),
		'data.sample' => array(),
		'doc.manual_setup' => '',
		'doc.more_information' => '',
		'settings' => array(),
	)
);

?>

